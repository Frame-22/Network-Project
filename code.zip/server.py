import socket
import threading
import os
import mimetypes

HOST = "0.0.0.0"
PORT = 5000

STORAGE_DIR = "server_files"

STATUS = {
    200: "OK",
    201: "CREATED",
    400: "BAD_REQUEST",
    404: "NOT_FOUND",
    409: "CONFLICT",
    500: "INTERNAL_SERVER_ERROR"
}

file_lock = threading.Lock()


# =========================================================
# MESSAGE FRAMING
# =========================================================

def send_message(sock, message):
    """
    Application-Layer Message
    ทุก Message จบด้วย \\n\\n
    """
    data = (message + "\n\n").encode("utf-8")
    sock.sendall(data)


def receive_message(sock):
    """
    รับข้อมูลจนกว่าจะเจอ \\n\\n
    """
    buffer = b""

    while b"\n\n" not in buffer:
        chunk = sock.recv(4096)

        if not chunk:
            return None

        buffer += chunk

    message, _ = buffer.split(b"\n\n", 1)

    return message.decode("utf-8")


# =========================================================
# RESPONSE
# =========================================================

def send_response(sock, status_code, body=""):

    phrase = STATUS[status_code]

    response = (
        f"FSMP/1.0 {status_code} {phrase}\n"
        f"{body}"
    )

    print("\n========== SEND RESPONSE ==========")
    print(response)
    print("===================================")

    send_message(sock, response)


# =========================================================
# PARSE REQUEST
# =========================================================

def parse_request(request):

    lines = request.split("\n")

    if len(lines) < 2:
        return None, {}

    if lines[0].strip() != "FSMP/1.0":
        return None, {}

    request_line = lines[1]

    if not request_line.startswith("REQUEST: "):
        return None, {}

    command = request_line[
        len("REQUEST: "):
    ].strip().upper()

    headers = {}

    for line in lines[2:]:

        if ":" in line:

            key, value = line.split(":", 1)

            headers[
                key.strip().upper()
            ] = value.strip()

    return command, headers


# =========================================================
# HELLO
# =========================================================

def handle_hello(sock, headers, address):

    client_id = headers.get("CLIENT-ID")

    if not client_id:

        send_response(
            sock,
            400,
            "MESSAGE: CLIENT-ID is required"
        )

        return None

    print(
        f"[HELLO] "
        f"{client_id} connected "
        f"from {address}"
    )

    send_response(
        sock,
        200,
        f"MESSAGE: Welcome\n"
        f"CLIENT-ID: {client_id}"
    )

    return client_id


# =========================================================
# LIST
# =========================================================

def handle_list(sock):

    with file_lock:
        files = os.listdir(STORAGE_DIR)

    if not files:

        send_response(
            sock,
            200,
            "FILES: 0"
        )

        return

    body = f"FILES: {len(files)}\n"

    for filename in files:
        body += f"{filename}\n"

    send_response(
        sock,
        200,
        body.rstrip()
    )


# =========================================================
# SEARCH
# =========================================================

def handle_search(sock, headers):

    query = headers.get("QUERY")

    if not query:

        send_response(
            sock,
            400,
            "MESSAGE: QUERY is required"
        )

        return

    query = query.lower()

    with file_lock:
        files = os.listdir(STORAGE_DIR)

    results = [
        f
        for f in files
        if query in f.lower()
    ]

    if not results:

        send_response(
            sock,
            200,
            "FILES: 0"
        )

        return

    body = f"FILES: {len(results)}\n"

    for filename in results:
        body += f"{filename}\n"

    send_response(
        sock,
        200,
        body.rstrip()
    )


# =========================================================
# INFO
# =========================================================

def handle_info(sock, headers):

    filename = headers.get("FILENAME")

    if not filename:

        send_response(
            sock,
            400,
            "MESSAGE: FILENAME is required"
        )

        return

    filename = os.path.basename(filename)

    filepath = os.path.join(
        STORAGE_DIR,
        filename
    )

    if not os.path.isfile(filepath):

        send_response(
            sock,
            404,
            f"MESSAGE: File not found\n"
            f"FILENAME: {filename}"
        )

        return

    size = os.path.getsize(filepath)

    file_type = mimetypes.guess_type(filename)[0]

    if file_type is None:
        file_type = "application/octet-stream"

    send_response(
        sock,
        200,
        f"FILENAME: {filename}\n"
        f"SIZE: {size}\n"
        f"TYPE: {file_type}"
    )


# =========================================================
# UPLOAD
# =========================================================

def handle_upload(sock, headers):

    filename = headers.get("FILENAME")
    size_text = headers.get("SIZE")

    if not filename or not size_text:

        send_response(
            sock,
            400,
            "MESSAGE: FILENAME and SIZE are required"
        )

        return

    filename = os.path.basename(filename)

    try:

        size = int(size_text)

        if size < 0:
            raise ValueError

    except ValueError:

        send_response(
            sock,
            400,
            "MESSAGE: Invalid SIZE"
        )

        return

    filepath = os.path.join(
        STORAGE_DIR,
        filename
    )

    with file_lock:

        if os.path.exists(filepath):

            send_response(
                sock,
                409,
                f"MESSAGE: File already exists\n"
                f"FILENAME: {filename}"
            )

            return

    # แจ้ง Client ว่าพร้อมรับไฟล์
    send_response(
        sock,
        200,
        "MESSAGE: READY"
    )

    received = 0

    with open(filepath, "wb") as file:

        while received < size:

            chunk = sock.recv(
                min(
                    4096,
                    size - received
                )
            )

            if not chunk:
                break

            file.write(chunk)

            received += len(chunk)

    if received != size:

        if os.path.exists(filepath):
            os.remove(filepath)

        send_response(
            sock,
            400,
            "MESSAGE: Incomplete file"
        )

        return

    send_response(
        sock,
        201,
        f"MESSAGE: Upload successful\n"
        f"FILENAME: {filename}\n"
        f"SIZE: {size}"
    )


# =========================================================
# DOWNLOAD
# =========================================================

def handle_download(sock, headers):

    filename = headers.get("FILENAME")

    if not filename:

        send_response(
            sock,
            400,
            "MESSAGE: FILENAME is required"
        )

        return

    filename = os.path.basename(filename)

    filepath = os.path.join(
        STORAGE_DIR,
        filename
    )

    if not os.path.isfile(filepath):

        send_response(
            sock,
            404,
            f"MESSAGE: File not found\n"
            f"FILENAME: {filename}"
        )

        return

    size = os.path.getsize(filepath)

    # ส่งข้อมูลไฟล์ก่อน
    send_response(
        sock,
        200,
        f"FILENAME: {filename}\n"
        f"SIZE: {size}"
    )

    # ส่ง File Data
    with open(filepath, "rb") as file:

        while True:

            chunk = file.read(4096)

            if not chunk:
                break

            sock.sendall(chunk)

    print(
        f"[DOWNLOAD] "
        f"{filename} "
        f"({size} bytes)"
    )


# =========================================================
# RENAME
# =========================================================

def handle_rename(sock, headers):

    old_name = headers.get("OLD-NAME")
    new_name = headers.get("NEW-NAME")

    if not old_name or not new_name:

        send_response(
            sock,
            400,
            "MESSAGE: OLD-NAME and NEW-NAME are required"
        )

        return

    old_name = os.path.basename(old_name)
    new_name = os.path.basename(new_name)

    old_path = os.path.join(
        STORAGE_DIR,
        old_name
    )

    new_path = os.path.join(
        STORAGE_DIR,
        new_name
    )

    with file_lock:

        if not os.path.isfile(old_path):

            send_response(
                sock,
                404,
                "MESSAGE: Original file not found"
            )

            return

        if os.path.exists(new_path):

            send_response(
                sock,
                409,
                "MESSAGE: New filename already exists"
            )

            return

        os.rename(
            old_path,
            new_path
        )

    send_response(
        sock,
        200,
        f"MESSAGE: Rename successful\n"
        f"OLD-NAME: {old_name}\n"
        f"NEW-NAME: {new_name}"
    )


# =========================================================
# DELETE
# =========================================================

def handle_delete(sock, headers):

    filename = headers.get("FILENAME")

    if not filename:

        send_response(
            sock,
            400,
            "MESSAGE: FILENAME is required"
        )

        return

    filename = os.path.basename(filename)

    filepath = os.path.join(
        STORAGE_DIR,
        filename
    )

    with file_lock:

        if not os.path.isfile(filepath):

            send_response(
                sock,
                404,
                "MESSAGE: File not found"
            )

            return

        os.remove(filepath)

    send_response(
        sock,
        200,
        f"MESSAGE: Delete successful\n"
        f"FILENAME: {filename}"
    )


# =========================================================
# CLIENT THREAD
# =========================================================

def handle_client(sock, address):

    client_id = "UNKNOWN"

    print(
        f"\n[CONNECTED] {address}"
    )

    print(
        f"[THREAD] "
        f"{threading.current_thread().name}"
    )

    try:

        while True:

            request = receive_message(sock)

            if request is None:
                break

            print(
                "\n========== RECEIVE REQUEST =========="
            )

            print(request)

            print(
                "====================================="
            )

            command, headers = parse_request(request)

            if command is None:

                send_response(
                    sock,
                    400,
                    "MESSAGE: Invalid FSMP request"
                )

                continue

            # HELLO
            if command == "HELLO":

                new_client_id = handle_hello(
                    sock,
                    headers,
                    address
                )

                if new_client_id:
                    client_id = new_client_id

            # LIST
            elif command == "LIST":

                handle_list(sock)

            # SEARCH
            elif command == "SEARCH":

                handle_search(
                    sock,
                    headers
                )

            # INFO
            elif command == "INFO":

                handle_info(
                    sock,
                    headers
                )

            # UPLOAD
            elif command == "UPLOAD":

                handle_upload(
                    sock,
                    headers
                )

            # DOWNLOAD
            elif command == "DOWNLOAD":

                handle_download(
                    sock,
                    headers
                )

            # RENAME
            elif command == "RENAME":

                handle_rename(
                    sock,
                    headers
                )

            # DELETE
            elif command == "DELETE":

                handle_delete(
                    sock,
                    headers
                )

            # QUIT
            elif command == "QUIT":

                send_response(
                    sock,
                    200,
                    f"MESSAGE: Goodbye\n"
                    f"CLIENT-ID: {client_id}"
                )

                break

            else:

                send_response(
                    sock,
                    400,
                    f"MESSAGE: Unknown command\n"
                    f"COMMAND: {command}"
                )

    except ConnectionResetError:

        print(
            f"[RESET] {client_id}"
        )

    except Exception as e:

        print(
            f"[ERROR] {client_id}: {e}"
        )

    finally:

        sock.close()

        print(
            f"[CLOSED] "
            f"{client_id} "
            f"{address}"
        )


# =========================================================
# MAIN SERVER
# =========================================================

def main():

    os.makedirs(
        STORAGE_DIR,
        exist_ok=True
    )

    server = socket.socket(
        socket.AF_INET,
        socket.SOCK_STREAM
    )

    server.setsockopt(
        socket.SOL_SOCKET,
        socket.SO_REUSEADDR,
        1
    )

    server.bind(
        (HOST, PORT)
    )

    server.listen(10)

    print("========================================")
    print("        FSMP SERVER v1.0")
    print("========================================")
    print(f"Address  : {HOST}:{PORT}")
    print("Protocol : FSMP/1.0")
    print("TCP      : ENABLED")
    print("Threading: ENABLED")
    print("========================================")
    print("Waiting for clients...\n")

    try:

        while True:

            client_socket, address = server.accept()

            thread = threading.Thread(
                target=handle_client,
                args=(
                    client_socket,
                    address
                ),
                daemon=True
            )

            thread.start()

            print(
                f"[NEW THREAD] "
                f"{thread.name} "
                f"-> {address}"
            )

    except KeyboardInterrupt:

        print(
            "\n[SERVER] Shutdown"
        )

    finally:

        server.close()


if __name__ == "__main__":
    main()