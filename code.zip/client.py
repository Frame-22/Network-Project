import socket
import os

SERVER_HOST = "127.0.0.1"
SERVER_PORT = 5000

CLIENT_ID = input(
    "Enter your Client ID: "
).strip()


# =========================================================
# MESSAGE FUNCTIONS
# =========================================================

def send_message(sock, message):

    print(
        "\n========== SEND REQUEST =========="
    )

    print(message)

    print(
        "=================================="
    )

    data = (
        message + "\n\n"
    ).encode("utf-8")

    sock.sendall(data)


def receive_message(sock):

    buffer = b""

    while b"\n\n" not in buffer:

        chunk = sock.recv(4096)

        if not chunk:
            return None

        buffer += chunk

    message, _ = buffer.split(
        b"\n\n",
        1
    )

    message = message.decode(
        "utf-8"
    )

    print(
        "\n========== RECEIVE RESPONSE =========="
    )

    print(message)

    print(
        "======================================="
    )

    return message


# =========================================================
# HELLO
# =========================================================

def hello(sock):

    request = (
        "FSMP/1.0\n"
        "REQUEST: HELLO\n"
        f"CLIENT-ID: {CLIENT_ID}"
    )

    send_message(
        sock,
        request
    )

    receive_message(sock)


# =========================================================
# LIST
# =========================================================

def list_files(sock):

    request = (
        "FSMP/1.0\n"
        "REQUEST: LIST"
    )

    send_message(
        sock,
        request
    )

    receive_message(sock)


# =========================================================
# SEARCH
# =========================================================

def search_files(sock):

    query = input(
        "Search filename: "
    ).strip()

    request = (
        "FSMP/1.0\n"
        "REQUEST: SEARCH\n"
        f"QUERY: {query}"
    )

    send_message(
        sock,
        request
    )

    receive_message(sock)


# =========================================================
# INFO
# =========================================================

def file_info(sock):

    filename = input(
        "Filename: "
    ).strip()

    request = (
        "FSMP/1.0\n"
        "REQUEST: INFO\n"
        f"FILENAME: {filename}"
    )

    send_message(
        sock,
        request
    )

    receive_message(sock)


# =========================================================
# UPLOAD
# =========================================================

def upload_file(sock):

    filepath = input(
        "File path: "
    ).strip()

    if not os.path.isfile(filepath):

        print(
            "[ERROR] File does not exist"
        )

        return

    filename = os.path.basename(
        filepath
    )

    size = os.path.getsize(
        filepath
    )

    request = (
        "FSMP/1.0\n"
        "REQUEST: UPLOAD\n"
        f"FILENAME: {filename}\n"
        f"SIZE: {size}"
    )

    send_message(
        sock,
        request
    )

    response = receive_message(
        sock
    )

    if response is None:
        return

    if not response.startswith(
        "FSMP/1.0 200 OK"
    ):

        print(
            "[UPLOAD FAILED]"
        )

        return

    print(
        "[SERVER] Ready to receive file"
    )

    with open(
        filepath,
        "rb"
    ) as file:

        while True:

            chunk = file.read(4096)

            if not chunk:
                break

            sock.sendall(chunk)

    print(
        f"[FILE SENT] "
        f"{filename} "
        f"({size} bytes)"
    )

    receive_message(sock)


# =========================================================
# DOWNLOAD
# =========================================================

def download_file(sock):

    filename = input(
        "Filename: "
    ).strip()

    request = (
        "FSMP/1.0\n"
        "REQUEST: DOWNLOAD\n"
        f"FILENAME: {filename}"
    )

    send_message(
        sock,
        request
    )

    response = receive_message(
        sock
    )

    if response is None:
        return

    if not response.startswith(
        "FSMP/1.0 200 OK"
    ):

        print(
            "[DOWNLOAD FAILED]"
        )

        return

    lines = response.split(
        "\n"
    )

    filename = None
    size = None

    for line in lines:

        if line.startswith(
            "FILENAME:"
        ):

            filename = line.split(
                ":",
                1
            )[1].strip()

        elif line.startswith(
            "SIZE:"
        ):

            size = int(
                line.split(
                    ":",
                    1
                )[1].strip()
            )

    if filename is None or size is None:

        print(
            "[ERROR] Invalid metadata"
        )

        return

    os.makedirs(
        "downloads",
        exist_ok=True
    )

    filepath = os.path.join(
        "downloads",
        filename
    )

    received = 0

    print(
        f"[DOWNLOADING] "
        f"{filename} "
        f"({size} bytes)"
    )

    with open(
        filepath,
        "wb"
    ) as file:

        while received < size:

            chunk = sock.recv(
                min(
                    4096,
                    size - received
                )
            )

            if not chunk:
                break

            file.write(chunk)

            received += len(chunk)

    if received == size:

        print(
            f"[DOWNLOAD COMPLETE] "
            f"{filepath}"
        )

    else:

        print(
            "[DOWNLOAD FAILED] "
            "Incomplete file"
        )


# =========================================================
# RENAME
# =========================================================

def rename_file(sock):

    old_name = input(
        "Old filename: "
    ).strip()

    new_name = input(
        "New filename: "
    ).strip()

    request = (
        "FSMP/1.0\n"
        "REQUEST: RENAME\n"
        f"OLD-NAME: {old_name}\n"
        f"NEW-NAME: {new_name}"
    )

    send_message(
        sock,
        request
    )

    receive_message(sock)


# =========================================================
# DELETE
# =========================================================

def delete_file(sock):

    filename = input(
        "Filename: "
    ).strip()

    request = (
        "FSMP/1.0\n"
        "REQUEST: DELETE\n"
        f"FILENAME: {filename}"
    )

    send_message(
        sock,
        request
    )

    receive_message(sock)


# =========================================================
# QUIT
# =========================================================

def quit_client(sock):

    request = (
        "FSMP/1.0\n"
        "REQUEST: QUIT"
    )

    send_message(
        sock,
        request
    )

    receive_message(sock)


# =========================================================
# MAIN
# =========================================================

def main():

    print("========================================")
    print("        FSMP CLIENT v1.0")
    print("========================================")
    print(
        f"Client ID: {CLIENT_ID}"
    )

    sock = socket.socket(
        socket.AF_INET,
        socket.SOCK_STREAM
    )

    try:

        sock.connect(
            (
                SERVER_HOST,
                SERVER_PORT
            )
        )

    except ConnectionRefusedError:

        print(
            "[ERROR] Cannot connect to Server"
        )

        return

    print(
        f"[CONNECTED] "
        f"{SERVER_HOST}:{SERVER_PORT}"
    )

    # แนะนำตัว
    hello(sock)

    while True:

        print(
            "\n========== FSMP MENU =========="
        )

        print("1. List files")
        print("2. Search file")
        print("3. File information")
        print("4. Upload file")
        print("5. Download file")
        print("6. Rename file")
        print("7. Delete file")
        print("8. Quit")

        print(
            "================================"
        )

        choice = input(
            "Select: "
        ).strip()

        if choice == "1":

            list_files(sock)

        elif choice == "2":

            search_files(sock)

        elif choice == "3":

            file_info(sock)

        elif choice == "4":

            upload_file(sock)

        elif choice == "5":

            download_file(sock)

        elif choice == "6":

            rename_file(sock)

        elif choice == "7":

            delete_file(sock)

        elif choice == "8":

            quit_client(sock)

            break

        else:

            print(
                "[ERROR] Invalid choice"
            )

    sock.close()

    print(
        "[CLIENT] Connection closed"
    )


if __name__ == "__main__":
    main()